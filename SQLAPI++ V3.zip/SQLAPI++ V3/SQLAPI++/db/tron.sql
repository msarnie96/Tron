/*                                                                        */
/*              tron.SQL - Creates the tron database                  */ 
/*                                                                        */
/*
** Copyright NHTI 2017
** All Rights Reserved.
*/

SET NOCOUNT ON
GO

set nocount    on
set dateformat mdy

USE master

declare @dttm varchar(55)
select  @dttm=convert(varchar,getdate(),113)
raiserror('Beginning tron.SQL at %s ....',1,1,@dttm) with nowait

GO

if exists (select * from sysdatabases where name='tron')
begin
  raiserror('Dropping existing tron database ....',0,1)
  DROP database tron
end
GO

CHECKPOINT
GO

raiserror('Creating tron database....',0,1)
GO

CHECKPOINT
GO


CREATE DATABASE tron;
GO

CHECKPOINT
GO

USE tron
GO

CREATE TABLE playerinfo
(
	PRIMARY KEY(uname),
	uname VARCHAR(20), 
    	wins INT NULL, 
    	loss INT NULL,
	
);

CREATE TABLE gameinfo
(
    PRIMARY KEY(gameID),
	gameID VARCHAR(20), 
    	player1 VARCHAR(20) NULL, 
    	player2 VARCHAR(20) NULL,
	winner VARCHAR(20) NOT NULL,
	
);
