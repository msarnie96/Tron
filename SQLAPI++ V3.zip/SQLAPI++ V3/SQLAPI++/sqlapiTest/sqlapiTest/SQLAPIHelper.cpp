#include "SQLAPIHelper.h"
using namespace std;

void SQLAPI::GetAllPlayerInfo()
{
	SAConnection con;

	SACommand cmd;    // command object

	try
	{
		// connect to database (Oracle in our example)
		con.Connect("tron", "", "", SA_SQLServer_Client);

		// associate a command with connection
		// connection can also be specified in SACommand constructor
		cmd.setConnection(&con);

		// create table
		cmd.setCommandText("SELECT * FROM playerinfo");

		// Select from our test table
		cmd.Execute();
		// fetch results row by row and print results
		int i = 1;
		cout << setw(7) << "Sl. No:" << setw(15) << "Username" << setw(15) << "Wins"
			<< setw(15) << "Losses" << endl << endl;
		while (cmd.FetchNext())
		{
			cout << setw(7) << i << setw(15) << (const char*)cmd.Field("uname").asString() << setw(15) << (const char*)cmd.Field("wins").asString() <<
				setw(15) << (const char*)cmd.Field("loss").asString() << endl;

			i++;
		}

		// commit changes on success
		con.Commit();

		printf("Rows selected!\n");
	}
	catch (SAException &x)
	{
		// SAConnection::Rollback()
		// can also throw an exception
		// (if a network error for example),
		// we will be ready
		try
		{
			// on error rollback changes
			con.Rollback();
		}
		catch (SAException &)
		{
		}
		// print error message
		printf("%s\n", (const char*)x.ErrText());
	}
}
std::string SQLAPI::GetPlayerByUname(char uname[])
{
	
	SAConnection con;

	SACommand cmd;    // command object
	try
	{
		// connect to database (Oracle in our example)
		con.Connect("tron", "", "", SA_SQLServer_Client);

		// associate a command with connection
		// connection can also be specified in SACommand constructor
		cmd.setConnection(&con);

		// create table
		cmd.setCommandText(
			"SELECT * FROM playerinfo WHERE uname = :1");
		// use first method of binding - param assignment
		cmd.Param(1).setAsString() = uname;
		cmd.Execute();

		int i = 1;
		cout << setw(7) << "Sl. No:" << setw(15) << "Player ID" << setw(15)  << "Wins" << setw(15) << "Losses" << endl;

		while (cmd.FetchNext())
		{
			cout << setw(7) << i << setw(15) << (const char*)cmd.Field("uname").asString() << setw(15) << (const char*)cmd.Field("wins").asString() <<
				setw(15) << (const char*)cmd.Field("loss").asString() << endl;

			i++;
		}
		SAString uname = (const char*)cmd.Field("uname").asString();
		SAString wins = (const char*)cmd.Field("wins").asString();
		SAString loss = (const char*)cmd.Field("loss").asString();
		SAString dataString = uname + DCHAR + wins + DCHAR + loss;

		string playerInformation = uname + DCHAR + wins + DCHAR + loss;
		// commit changes on success
		con.Commit();

		printf("\nPlayer Found!\n");
		return playerInformation;
	}
	catch (SAException &x)
	{
		// print error message
		printf("%s\n", (const char*)x.ErrText());
		return false;
	}


}
void SQLAPI::AddPlayer(char uname[])
{
	SAConnection con;

	SACommand cmd;    // command object

	try
	{
		// connect to database (Oracle in our example)
		con.Connect("tron", "", "", SA_SQLServer_Client);

		// associate a command with connection
		// connection can also be specified in SACommand constructor
		cmd.setConnection(&con);

		// create table
		cmd.setCommandText(
			"INSERT INTO playerinfo (uname, wins, loss) values (:1,0,0)");
		// use first method of binding - param assignment
		cmd.Param(1).setAsString() = uname;
		cmd.Execute();

		// commit changes on success
		con.Commit();

		printf("\nPlayer Created!\n");
	}
	catch (SAException &x)
	{
		// print error message
		printf("%s\n", (const char*)x.ErrText());
	}
}
void SQLAPI::UpdatePlayerScore(char uname[], bool won)
{
	SAConnection con;

	SACommand cmd;    // command object

	try
	{
		if (won)
		{
			// connect to database (Oracle in our example)
			con.Connect("tron", "", "", SA_SQLServer_Client);

			// associate a command with connection
			// connection can also be specified in SACommand constructor
			cmd.setConnection(&con);

			// create table
			cmd.setCommandText(
				"UPDATE playerinfo SET wins = wins + 1, loss = loss + 0 WHERE uname = :1");
			// use first method of binding - param assignment
			cmd.Param(1).setAsString() = uname;
			cmd.Execute();

			// commit changes on success
			con.Commit();

			printf("Score Updated!\n");
		}
		if (!won)
		{
			// connect to database (Oracle in our example)
			con.Connect("tron", "", "", SA_SQLServer_Client);

			// associate a command with connection
			// connection can also be specified in SACommand constructor
			cmd.setConnection(&con);

			// create table
			cmd.setCommandText(
				"UPDATE playerinfo SET wins = wins + 0, loss = loss + 1 WHERE uname = :1");
			// use first method of binding - param assignment
			cmd.Param(1).setAsString() = uname;
			cmd.Execute();

			// commit changes on success
			con.Commit();

			printf("Score Updated!\n");
		}
		
	}
	catch (SAException &x)
	{
		// SAConnection::Rollback()
		// can also throw an exception
		// (if a network error for example),
		// we will be ready
		try
		{
			// on error rollback changes
			con.Rollback();
		}
		catch (SAException &)
		{
		}
		// print error message
		printf("%s\n", (const char*)x.ErrText());
	}
}
void SQLAPI::UpdatePlayerName(char uname[], char newName[])
{
	SAConnection con;

	SACommand cmd;    // command object

	try
	{
		// connect to database (Oracle in our example)
		con.Connect("tron", "", "", SA_SQLServer_Client);

		// associate a command with connection
		// connection can also be specified in SACommand constructor
		cmd.setConnection(&con);

		// create table
		cmd.setCommandText(
			"UPDATE playerinfo SET uname = :2 WHERE uname = :1");
		// use first method of binding - param assignment
		cmd.Param(1).setAsString() = uname;
		cmd.Param(2).setAsString() = newName;
		cmd.Execute();

		// commit changes on success
		con.Commit();

		printf("Username Updated!\n");
	}
	catch (SAException &x)
	{
		// SAConnection::Rollback()
		// can also throw an exception
		// (if a network error for example),
		// we will be ready
		try
		{
			// on error rollback changes
			con.Rollback();
		}
		catch (SAException &)
		{
		}
		// print error message
		printf("%s\n", (const char*)x.ErrText());
	}
}
void SQLAPI::DeletePlayer(char uname[])
{

	SAConnection con;

	SACommand cmd;    // command object

	try
	{
		// connect to database (Oracle in our example)
		con.Connect("tron", "", "", SA_SQLServer_Client);

		// associate a command with connection
		// connection can also be specified in SACommand constructor
		cmd.setConnection(&con);

		// create table
		cmd.setCommandText(
			"DELETE FROM playerinfo WHERE uname = :1");
		// use first method of binding - param assignment
		cmd.Param(1).setAsString() = uname;
		cmd.Execute();

		// commit changes on success
		con.Commit();

		printf("Player deleted!\n");
	}
	catch (SAException &x)
	{
		// SAConnection::Rollback()
		// can also throw an exception
		// (if a network error for example),
		// we will be ready
		try
		{
			// on error rollback changes
			con.Rollback();
		}
		catch (SAException &)
		{
		}
		// print error message
		printf("%s\n", (const char*)x.ErrText());
	}
}

void SQLAPI::GetAllGameInfo()
{
	SAConnection con;

	SACommand cmd;    // command object

	try
	{
		// connect to database (Oracle in our example)
		con.Connect("tron", "", "", SA_SQLServer_Client);

		// associate a command with connection
		// connection can also be specified in SACommand constructor
		cmd.setConnection(&con);

		// create table
		cmd.setCommandText("SELECT * FROM gameinfo");

		// Select from our test table
		cmd.Execute();
		// fetch results row by row and print results

		int i = 1;
		cout << setw(7) << "Sl. No:" << setw(15) << "GameID" << setw(15) << "Player 1"
			<< setw(15) << "Player 2" << setw(15) << "Winner" << endl;

		while (cmd.FetchNext())
		{
			cout << setw(7) << i << setw(15) << (const char*)cmd.Field("gameID").asString() << setw(15) << (const char*)cmd.Field("player1").asString() <<
				setw(15) << (const char*)cmd.Field("player2").asString() << setw(15) << (const char*)cmd.Field("winner").asString() << endl;

			i++;
		}
		

		// commit changes on success
		con.Commit();

		printf("Rows selected!\n");
	}
	catch (SAException &x)
	{
		// print error message
		printf("%s\n", (const char*)x.ErrText());
	}
}
void SQLAPI::AddGame(char gameID[], char p1[], char p2[])
{
	SAConnection con;

	SACommand cmd;    // command object

	try
	{
		// connect to database (Oracle in our example)
		con.Connect("tron", "", "", SA_SQLServer_Client);

		// associate a command with connection
		// connection can also be specified in SACommand constructor
		cmd.setConnection(&con);

		// create table
		cmd.setCommandText(
			"INSERT INTO gameinfo (gameID, player1, player2, winner) values (:1, :2, :3, 0)");
		// use first method of binding - param assignment
		cmd.Param(1).setAsString() = gameID;
		cmd.Param(2).setAsString() = p1;
		cmd.Param(3).setAsString() = p2;

		cmd.Execute();

		// commit changes on success
		con.Commit();

		printf("row inserted!\n");
	}
	catch (SAException &x)
	{
		// print error message
		printf("%s\n", (const char*)x.ErrText());
	}

}
void SQLAPI::UpdateGame(char gameID[], char winner[])
{
	SAConnection con;

	SACommand cmd;    // command object

	try
	{
		// connect to database (Oracle in our example)
		con.Connect("tron", "", "", SA_SQLServer_Client);

		// associate a command with connection
		// connection can also be specified in SACommand constructor
		cmd.setConnection(&con);

		// create table
		cmd.setCommandText(
			"UPDATE gameinfo SET winner = :2 WHERE gameID = :1");
		// use first method of binding - param assignment
		cmd.Param(1).setAsString() = gameID;
		cmd.Param(2).setAsString() = winner;
		cmd.Execute();

		// commit changes on success
		con.Commit();

		printf("row inserted!\n");
	}
	catch (SAException &x)
	{
		// SAConnection::Rollback()
		// can also throw an exception
		// (if a network error for example),
		// we will be ready
		try
		{
			// on error rollback changes
			con.Rollback();
		}
		catch (SAException &)
		{
		}
		// print error message
		printf("%s\n", (const char*)x.ErrText());
	}

	
}
void SQLAPI::DeleteGame(char gameID[])
{
	SAConnection con;
	SACommand cmd;    // command object

	try
	{
		// connect to database (Oracle in our example)
		con.Connect("tron", "", "", SA_SQLServer_Client);

		// associate a command with connection
		// connection can also be specified in SACommand constructor
		cmd.setConnection(&con);

		// create table
		cmd.setCommandText(
			"DELETE FROM gameinfo WHERE gameID = :1");
		// use first method of binding - param assignment
		cmd.Param(1).setAsString() = gameID;
		cmd.Execute();

		// commit changes on success
		con.Commit();

		printf("row deleted!\n");
	}
	catch (SAException &x)
	{
		// print error message
		printf("%s\n", (const char*)x.ErrText());
	}

}

/*

try
{

}
catch (SAException &x)
{

}

*/

