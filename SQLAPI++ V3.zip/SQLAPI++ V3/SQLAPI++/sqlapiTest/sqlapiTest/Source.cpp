#include <iostream>
#include <SQLAPI.h>
#include "SQLAPIHelper.h"

using namespace std;

void main()
{
	SQLAPI api;


	//Testing for creating new users
	/*
	char uname[] = "hjdfsa";
	char gameID[] = "Test Game";
	char p1[] = "Mike";
	char p2[] = "Brendan";
	char wins[] = "420";
	char loss[] = "0";
	*/


	/*
	char uname[20];
	bool quit = false;
	while (quit != true)
	{
		cout << "Create New User!\n";
		cin >> uname;
		
		api.AddPlayer(uname);
	}
	*/


	//Testing for Getting player by username
	/*
	char uname[20];

	bool quit = false;
	while (quit != true)
	{
		cout << "Find User!\n";
		cin >> uname;

		std::string test = api.GetPlayerByUname(uname);
		
	}
	*/


	//Testing for incrementing wins and losses
	/*
	char uname[20];
	char stat;
	bool quit = false;
	while (quit != true)
	{
		cout << "Enter Username!\n";
		cin >> uname;
		cout << "\n Did you win or lose?\n";
		cin >> stat;
		
		if (stat == 'w')
		{
			api.UpdatePlayerScore(uname, true);
		}
		if (stat == 'l')
		{
			api.UpdatePlayerScore(uname, false);
		}
		
	}
	*/


	//Testing Deleting Usernames
	/*
	char uname[20];
	char stat;
	bool quit = false;
	while (quit != true)
	{
		cout << "Enter Username!\n";
		cin >> uname;

		api.DeletePlayer(uname);
	}
	*/


	//Testing Updating Usernames
	/*
	char uname[20];
	char newName[20];

	bool quit = false;
	while (quit != true)
	{
		cout << "Enter Username!\n";
		cin >> uname;
		cout << "Enter New Username!\n";
		cin >> newName;

		api.UpdatePlayerName(uname, newName);
	}
	*/
	
	
	//api.AddPlayer(uname);
	api.GetAllPlayerInfo();
	//api.UpdatePlayer(uname, wins, loss);
	//api.DeletePlayer(uname);

	//api.GetAllGameInfo();
	//api.AddGame(gameID, p1, p2);
	//api.UpdateGame(gameID, p2);
	//api.DeleteGame(gameID);
	
}
