#pragma once
#include <iostream>
#include <stdio.h>
#include <iomanip>
#include <SQLAPI.h>
#include <string>

class SQLAPI
{
	
private:
	struct playerinfo {
		char _uname;
		char _wins;
		char _loss;
	};

	struct gameinfo {
		char _gameID;
		char _player1;
		char _player2;
		char _winner;
	};
public:
	const char DCHAR = '*';

	void GetAllPlayerInfo();
	std::string GetPlayerByUname(char uname[]);
	void AddPlayer(char uname[]);
	void UpdatePlayerScore(char uname[], bool won);
	void UpdatePlayerName(char uname[], char newName[]);
	void DeletePlayer(char uname[]);

	void GetAllGameInfo();
	void AddGame(char gameID[], char p1[], char p2[]);
	void UpdateGame(char gameID[], char winner[]);
	void DeleteGame(char gameID[]);
};