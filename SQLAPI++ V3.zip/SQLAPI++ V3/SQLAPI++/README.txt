HOW TO USE SQLAPI++:
_________________________________________________________________

lib:

Properties->Linker->Input
	-Add these to project properties
		sqlapi.lib
		sqlapid.lib
		sqlapis.lib
		sqlapisd.lib

Properties->Linker->Additional Library Directories ../your/bin
	-link bin directory to library project properties

_________________________________________________________________

h:

Properties->General->Additional Include Directories: ../your/include
	-link include (header) directory to project properies

_________________________________________________________________

dlls:

MAKE SURE DLLs (sqlapi.dll, sqlapid.dll) are in Debug folder!

_________________________________________________________________



Open SQL Server Database and create new database called tron.
Copy and paste tron.sql into a new sql server query
Database is created empty.
